# KRISH Colour — phone se APK build karne ke liye

## Pehle samjho
Yeh **virtual-coins demo** hai. Isme real money, deposits, betting, ya withdrawals nahi hain. ZIP khud APK nahi hai.

## Android phone se APK kaise nikalein
1. Is ZIP ko download karke extract karein. Files app mein ZIP par tap karke Extract karein.
2. GitHub par apna account banayein / sign in karein: https://github.com
3. GitHub mein **New repository** banayein, naam `krish-colour-demo` rakh sakte hain. Public ya private, aapki choice.
4. Repository ke andar **Add file → Upload files** choose karein. Extracted folder ke andar ki files upload karein—`package.json`, `capacitor.config.json`, `www` folder, aur `.github` folder bhi zaroor upload hon.
   - Dhyan: ZIP file ko sirf repository mein rakh dena kaafi nahi; uske andar ki files upload honi chahiye.
5. **Commit changes** dabayein.
6. Repository mein **Actions** tab kholein. `Build Android APK` workflow select karein. Agar run apne aap shuru nahi hua, **Run workflow** dabayein.
7. Build complete hone par green tick wale run ko kholein. Neeche **Artifacts** mein `KRISH-Colour-Demo-APK` milega. Use download karein.
8. Artifact ZIP ko Files app mein extract karein. Andar `app-debug.apk` milega. Use tap karke install karein. Phone agar permission maange, to sirf GitHub se apne banaye APK ke liye browser/files app ko “Install unknown apps” permission dene ka faisla khud karein; baad mein permission off kar sakte hain.

## Agar dikkat aaye
- GitHub mobile app ke bajay Chrome mein github.com kholkar **Desktop site** try karein.
- `.github/workflows/android.yml` upload na hua to Actions workflow nahi dikhega.
- Build fail ho to red error ka screenshot bhej dein; main error samjha dunga.
- APK build hone ki guarantee nahi di ja sakti jab tak Actions run complete na ho. Yeh unsigned debug/testing APK hai, Play Store release nahi.
